FactoryGirl.define do

	factory :movie do

		id '1'
		title 'A fake title' # default values
		rating 'PG'
		release_date { 10.years.ago }
		director 'A fake director'

	end

end